console.log("hello world")
var n = 1;
var c = 2;
var a = n+c;
console.log("resultado:"+ a)

var a = 1;
var b = 2;
var r = a*b;
console.log("resultado:"+ r)

var raiz=Math.sqrt(1244);
console.log("La raiz cuadrada de 1244 es: "+raiz);

var raiz2=Math.trunc(raiz);
console.log("el numero mas cercano es: "+raiz2);

const esPrimo = numero => {
	// Casos especiales
	if (numero == 0 || numero == 1 || numero == 4) return false;
	for (let x = 2; x < numero / 2; x++) {
		if (numero % x == 0) return false;
	}
	// Si no se pudo dividir por ninguno de los de arriba, sí es primo
	return true;
}